
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class RandomWalk {
    private int x = 0;
    private int y = 0;
   // Random r = new Random();
    private final Random r = new Random();

    private void move(int dx, int dy) {
        // TODO you need to implement this
		x = x + dx;
		y = y + dy;
    }

    /**
     * Perform a random walk of m steps
     * @param m the number of steps the drunkard takes
     */
    private void randomWalk(int m, int l) {
        for (int i = 0; i < m; i++)
            randomMove(l);
    }

    private void randomMove(int l) {
        // TODO you need to implement this
    	
			int d = r.nextInt(4);
			switch (d) {
			case 0: { // move north
				move(0, l);
				break;
			}
			case 1: { // move south
				move(0, -l);
				break;
			}
			case 2: { // move east
				move(l, 0);
				break;
			}
			case 3: { // move west
				move(-l, 0);
				break;
			}
			}
		

		
    }

    public double distance() {
//    	System.out.println("x:"+x);
//    	System.out.println("y:" +y);
//    	System.out.println(Math.sqrt((x * x) + (y * y)));
		return Math.sqrt((x * x) + (y * y)); // TODO you need to implement this
    }

    /**
     * Perform multiple random walk experiments, returning the mean distance.
     * @param m the number of steps for each experiment
     * @param n the number of experiments to run
     * @return the mean distance
     */
    public static double randomWalkMulti(int m, int n,int l) {
        double totalDistance = 0;
        for (int i = 0; i < n; i++){
            RandomWalk walk = new RandomWalk();
            walk.randomWalk(m,l);
            totalDistance = totalDistance + walk.distance();
        }
        return totalDistance/n;
    }

    public static void main(String[] args) throws IOException {
       // if (args.length==0)
            //throw new RuntimeException("Syntax: RandomWalk steps [experiments]");
    	
    	//writing into CSV files
    	
    	String csvFile = "Analysis_with_varying_step_size_partb.csv";
        FileWriter writer;
		try {
			writer = new FileWriter(csvFile);
		   
			 for(int l =1; l<10; l++) {
		     for(int n=0; n<=1000;n=n+100) {
		    	
		         int m = 10;
		       //  int n = i;
		        // if (args.length > 1) n = Integer.parseInt(args[1]);
		         double meanDistance = randomWalkMulti(n,m,l);
		         
		         writeLine(writer, Arrays.asList(String.valueOf(n), String.valueOf((Math.pow((meanDistance),2))/Math.pow(l,2)),String.valueOf(l)));
		         System.out.println(n + " steps: " + meanDistance + "for step size " + l+ " over "+ m + " experiments");
		         
		    	 }
		     	} 


		        writer.flush();
		        writer.close();
		    	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

   
    	
    	
    	
    }
    
    
private static final char DEFAULT_SEPARATOR = ',';
    
    public static void writeLine(Writer w, List<String> values) throws IOException {
        writeLine(w, values, DEFAULT_SEPARATOR, ' ');
    }

    public static void writeLine(Writer w, List<String> values, char separators) throws IOException {
        writeLine(w, values, separators, ' ');
    }

   
    private static String followCVSformat(String value) {

        String result = value;
        if (result.contains("\"")) {
            result = result.replace("\"", "\"\"");
        }
        return result;

    }

    public static void writeLine(Writer w, List<String> values, char separators, char customQuote) throws IOException {

        boolean first = true;

        //default customQuote is empty

        if (separators == ' ') {
            separators = DEFAULT_SEPARATOR;
        }

        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (!first) {
                sb.append(separators);
            }
            if (customQuote == ' ') {
                sb.append(followCVSformat(value));
            } else {
                sb.append(customQuote).append(followCVSformat(value)).append(customQuote);
            }

            first = false;
        }
        sb.append("\n");
        w.append(sb.toString());
    }
}




